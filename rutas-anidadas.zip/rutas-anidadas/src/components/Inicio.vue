<template>
    <div id="Inicio">
        <h2>Bienvenido a nuestra pagina web</h2>
        <img id="garfield" src="./garfield.jpg" alt="dibujo">
    </div>
</template>

<script>
    export default{
        name:'Inicio',
    }
</script>

<style scoped>
    #Inicio{
        margin:30px;
        font-size:40px;
    }
    #garfield{
        display:block;
        margin:20px;
        width:400px;
        height:300px;
    }
</style>