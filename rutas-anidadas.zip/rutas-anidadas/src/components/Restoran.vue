<template>
    <div id="Restoran">
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'Restoran'
    }
</script>

